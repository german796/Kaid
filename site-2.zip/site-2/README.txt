KAI.D — САЙТ ДЛЯ CLOUDFLARE PAGES

Структура: public/ (сайт), functions/ (счётчики, скачивание, админка).

1. ЗАЛИТЬ НА CLOUDFLARE PAGES
   Надёжнее всего через GitHub: залей эту папку в репозиторий, в Cloudflare
   Workers & Pages -> Create -> Pages -> Connect to Git. Настройки сборки:
   Build command: пусто, Build output directory: public.
   Либо из консоли: npx wrangler pages deploy public
   (перетаскивание папки в панель может НЕ подхватить папку functions).

2. БАЗА ДЛЯ СТАТИСТИКИ (D1)
   Workers & Pages -> D1 -> Create database (имя любое, например kaid-stats).
   Проект Pages -> Settings -> Bindings -> Add -> D1 database:
   Variable name = DB, выбери созданную базу. Таблица создастся сама.

3. ПАРОЛЬ АДМИНКИ
   Проект Pages -> Settings -> Variables and Secrets: добавь
   ADMIN_USER и ADMIN_PASS (Secret). Без них /admin закрыт.
   Необязательно: TZ_OFFSET (часы от UTC, по умолчанию 3 = Москва).
   После добавления привязок и переменных сделай новый деплой.

4. ФАЙЛ ПРИЛОЖЕНИЯ (APK)
   Вариант А (до 25 МБ): положи файл с именем Kai.D.apk в public/downloads.
   Вариант Б (любой размер, рекомендую): создай R2-бакет, загрузи туда .apk,
   в проекте Pages -> Settings -> Bindings -> R2 bucket: Variable name = APK.
   Новый .apk в бакете подхватывается сам (берётся самый свежий).
   Пока файла нет, по кнопке показывается «Приложение в разработке»,
   а нажатия всё равно считаются.

5. ПРОВЕРКА
   Сайт: твой-домен/   Админка: твой-домен/admin
