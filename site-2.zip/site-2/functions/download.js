// Отдаёт APK: из R2 (привязка APK) или из public/downloads/Kai.D.apk
export async function onRequest({ request, env }) {
  if (env.APK) {
    const l = await env.APK.list({ limit: 100 });
    const f = l.objects.filter(o => /\.apk$/i.test(o.key)).sort((x, y) => y.uploaded - x.uploaded)[0];
    if (f) {
      const o = await env.APK.get(f.key, { range: request.headers });
      const h = new Headers();
      o.writeHttpMetadata(h);
      h.set('etag', o.httpEtag);
      h.set('Content-Type', 'application/vnd.android.package-archive');
      h.set('Content-Disposition', `attachment; filename="${f.key.split('/').pop()}"`);
      h.set('Accept-Ranges', 'bytes');
      if (o.range) {
        const s = o.range.offset ?? 0, len = o.range.length ?? o.size - s;
        h.set('Content-Range', `bytes ${s}-${s + len - 1}/${o.size}`);
        h.set('Content-Length', len);
        return new Response(o.body, { status: 206, headers: h });
      }
      h.set('Content-Length', o.size);
      return new Response(o.body, { headers: h });
    }
  }
  return Response.redirect(new URL('/downloads/Kai.D.apk', request.url), 302);
}
