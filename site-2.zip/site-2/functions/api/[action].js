// /api/hit, /api/click (счётчики) и /api/file (есть ли APK)
let ready;
export async function onRequest({ request, env, params }) {
  const a = params.action;
  const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
  if (a === 'file') {
    if (env.APK) {
      const l = await env.APK.list({ limit: 100 });
      const f = l.objects.filter(o => /\.apk$/i.test(o.key)).sort((x, y) => y.uploaded - x.uploaded)[0];
      if (f) return J({ ok: true, name: f.key.split('/').pop(), mb: +(f.size / 1048576).toFixed(1) });
    }
    const r = await env.ASSETS.fetch(new URL('/downloads/Kai.D.apk', request.url), { method: 'HEAD' });
    const ct = r.headers.get('content-type') || '';
    return r.ok && !ct.includes('text/html')
      ? J({ ok: true, name: 'Kai.D.apk', mb: +((+r.headers.get('content-length') || 0) / 1048576).toFixed(1) })
      : J({ ok: false });
  }
  if (request.method === 'POST' && (a === 'hit' || a === 'click')) {
    let id = '';
    try { id = String((await request.json()).u || ''); } catch (e) {}
    if (env.DB && /^[a-z0-9]{8,40}$/i.test(id)) {
      if (!ready) { await env.DB.exec('CREATE TABLE IF NOT EXISTS events (t INTEGER, u TEXT, k TEXT)'); ready = 1; }
      await env.DB.prepare('INSERT INTO events VALUES (?, ?, ?)').bind(Date.now(), id, a).run();
    }
    return J({ ok: 1 });
  }
  return J({ error: 1 }, 404);
}
