// /admin — статистика в стиле 1990-х. Пароль: переменные ADMIN_USER и ADMIN_PASS
const T = { 'Content-Type': 'text/plain;charset=utf-8' };
export async function onRequest({ request, env }) {
  const u = env.ADMIN_USER, p = env.ADMIN_PASS;
  if (!u || !p) return new Response('Задай ADMIN_USER и ADMIN_PASS в настройках проекта Cloudflare Pages', { status: 503, headers: T });
  let c = '';
  try { c = new TextDecoder().decode(Uint8Array.from(atob((request.headers.get('authorization') || '').match(/^Basic (.+)$/)[1]), x => x.charCodeAt(0))); } catch (e) {}
  if (c !== u + ':' + p) return new Response('Нужен пароль', { status: 401, headers: { ...T, 'WWW-Authenticate': 'Basic realm="Admin"' } });

  const OFF = (+env.TZ_OFFSET || 3) * 36e5, D = 864e5, now = Date.now();
  const t0 = Math.floor((now + OFF) / D) * D - OFF;
  const W = [['Сегодня', t0], ['7 дней', now - 7 * D], ['30 дней', now - 30 * D], ['365 дней', now - 365 * D], ['Всё время', 0]];
  let body;
  if (!env.DB) body = '<p><b>База D1 не подключена.</b> Добавь привязку DB в настройках проекта (см. README).</p>';
  else {
    await env.DB.exec('CREATE TABLE IF NOT EXISTS events (t INTEGER, u TEXT, k TEXT)');
    const q = (k, t) => env.DB.prepare('SELECT COUNT(*) n, COUNT(DISTINCT u) p FROM events WHERE k=? AND t>=?').bind(k, t).first();
    const row = async k => (await Promise.all(W.map(w => q(k, w[1])))).map(r => `<td>${r.p}</td><td>${r.n}</td>`).join('');
    const dr = (await env.DB.prepare('SELECT CAST((t+?)/86400000 AS INTEGER) d, k, COUNT(*) n, COUNT(DISTINCT u) p FROM events WHERE t>=? GROUP BY d,k').bind(OFF, t0 - 13 * D).all()).results;
    const g = (d, k) => dr.find(r => r.d === d && r.k === k) || { n: 0, p: 0 };
    const d0 = Math.floor((now + OFF) / D);
    let days = '';
    for (let i = 0; i < 14; i++) { const d = d0 - i, h = g(d, 'hit'); days += `<tr><td>${new Date(d * D).toISOString().slice(0, 10)}</td><td>${h.p}</td><td>${h.n}</td><td>${g(d, 'click').n}</td></tr>`; }
    body = `<h2>Посещения сайта</h2><table border="1" cellpadding="4"><tr><th></th>${W.map(w => `<th colspan="2">${w[0]}</th>`).join('')}</tr><tr><th></th>${W.map(() => '<th>Людей</th><th>Визитов</th>').join('')}</tr><tr><td>Заходили на сайт</td>${await row('hit')}</tr><tr><td>Нажали «Скачать»</td>${await row('click')}</tr></table>
<p>Людей = уникальные посетители (по браузеру). Визитов = количество заходов.</p><hr><h2>Последние 14 дней</h2><table border="1" cellpadding="4"><tr><th>Дата</th><th>Людей</th><th>Визитов</th><th>Нажатий «Скачать»</th></tr>${days}</table>`;
  }
  return new Response(`<html><head><meta charset="utf-8"><title>Admin</title></head><body bgcolor="white" text="black"><h1>Статистика Kai.D</h1><hr>${body}</body></html>`, { headers: { 'Content-Type': 'text/html;charset=utf-8', 'Cache-Control': 'no-store' } });
}
